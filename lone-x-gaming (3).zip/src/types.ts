export type ResourceCategory =
  | 'all'
  | 'guides'
  | 'settings'
  | 'hud'
  | 'tournaments'
  | 'performance';

export interface ResourceItem {
  id: string;
  name: string;
  iconName: string;
  shortDescription: string;
  fullDescription?: string;
  version: string;
  updatedDate: string;
  category: ResourceCategory;
  downloadUrl: string;
  fileSize: string;
  fileType: string;
  downloadsCount: number;
  featured?: boolean;
  badge?: string;
  quickPreview?: {
    summary: string;
    highlights: string[];
    specs?: { label: string; value: string }[];
  };
}

export interface SocialLink {
  id: string;
  name: 'TikTok' | 'YouTube' | 'Telegram' | string;
  url: string;
  handle: string;
  followers: string;
  color: string;
  glowColor: string;
  icon: string;
}

export interface BannerSlide {
  id: string;
  image: string;
  title: string;
  subtitle: string;
  badge: string;
  description: string;
  ctaText: string;
  resourceId: string;
}

export interface FeaturedPromo {
  title: string;
  tagline: string;
  description: string;
  badge: string;
  releaseDate: string;
  bannerImage: string;
  resourceId: string;
  highlights: string[];
}
