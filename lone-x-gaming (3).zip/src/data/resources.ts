import { ResourceItem } from '../types';

export const RESOURCES_DATA: ResourceItem[] = [
  {
    id: 'sensitivity-guide',
    name: 'Sensitivity Guide',
    iconName: 'Crosshair',
    shortDescription:
      'Calibrated General, Red Dot, 2x, and 4x scope sensitivity charts tuned for snap headshots and smooth drag control on low, mid, and flagship phones.',
    fullDescription:
      'Complete tested sensitivity matrix for current patch. Includes DPI scales (392 - 600), fire button size (42% - 55%), and micro-adjustment drills for consistent headshot accuracy across all weapon categories.',
    version: 'v4.8.2',
    updatedDate: 'Sep 18, 2026',
    category: 'guides',
    downloadUrl: '#download-sensitivity-guide',
    fileSize: '3.4 MB',
    fileType: 'PDF Guide & Quick Sheet',
    downloadsCount: 14820,
    featured: true,
    badge: 'TOP POPULAR',
    quickPreview: {
      summary: 'Optimal in-game sensitivity recommendations for competitive battle royale matches.',
      highlights: [
        'General Sensitivity: 95 - 100 (smooth 180° flick)',
        'Red Dot: 90 - 95 (drag headshot sweet spot)',
        '2x Scope: 86 - 90 (mid-range stability)',
        '4x Scope: 78 - 83 (sniper tracking precision)',
        'Free Look: 70 - 75',
      ],
      specs: [
        { label: 'Recommended Fire Button', value: '46% - 52%' },
        { label: 'Button Placement', value: 'Lower right quadrant' },
        { label: 'Screen DPI', value: '411 - 520 DPI' },
        { label: 'Anti-Ban Safety', value: '100% In-Game Native' },
      ],
    },
  },
  {
    id: 'hud-guide',
    name: 'HUD Guide',
    iconName: 'LayoutGrid',
    shortDescription:
      'Pro custom HUD layout schematics for 2-finger thumb players, 3-finger hybrid, and 4-finger claw setups with button sizing and placement coordinates.',
    fullDescription:
      'Master your mechanical dexterity with tournament-tested HUD blueprints. Includes gloo wall quick-place button placement, crouch-shot trigger positioning, and joystick drift prevention settings.',
    version: 'v3.5.0',
    updatedDate: 'Sep 14, 2026',
    category: 'hud',
    downloadUrl: '#download-hud-guide',
    fileSize: '5.1 MB',
    fileType: 'ZIP Blueprint Pack',
    downloadsCount: 11450,
    badge: 'RECOMMENDED',
    quickPreview: {
      summary: 'High-speed reflex custom HUD layouts tailored for rapid Gloo Wall reaction and jump-shots.',
      highlights: [
        '2-Finger Fast Gloo Wall layout with left-hand fire toggle',
        '3-Finger Claw index trigger setup for instant jump + headshot',
        '4-Finger Full Claw layout with dedicated weapon swap keys',
        'Transparent opacity mapping to preserve wide visual field',
      ],
      specs: [
        { label: 'Gloo Wall Button', value: 'Left thumb / 95% size' },
        { label: 'Jump Button', value: 'Right index / 75% size' },
        { label: 'Crouch Button', value: 'Right thumb / 70% size' },
        { label: 'Quick Weapon Switch', value: 'Center-right / 80%' },
      ],
    },
  },
  {
    id: 'training-guide',
    name: 'Training Guide',
    iconName: 'Target',
    shortDescription:
      'Structured 15-minute daily aim routine, drag headshot practice drills, recoil reset timing, and movement cancellation warm-ups.',
    fullDescription:
      'Break through your skill plateau with deliberate training ground drills used by tier-1 esports athletes. Features target tracking routines, one-tap timing, and gloo wall box defense drills.',
    version: 'v2.9.1',
    updatedDate: 'Sep 10, 2026',
    category: 'guides',
    downloadUrl: '#download-training-guide',
    fileSize: '2.8 MB',
    fileType: 'PDF Training Manual',
    downloadsCount: 8930,
    quickPreview: {
      summary: 'Daily 15-minute warmup and mechanic drill schedule to build muscle memory.',
      highlights: [
        '5 Mins: Moving Target Drag Headshot calibration in Training Ground',
        '5 Mins: Close range Gloo Wall deployment & jump slide drills',
        '5 Mins: Lone Wolf 1v1 reaction warm-up without audio reliance',
        'Crosshair placement principles at head-level during sprint',
      ],
      specs: [
        { label: 'Daily Time', value: '15 - 20 Minutes' },
        { label: 'Difficulty', value: 'Beginner to Grandmaster' },
        { label: 'Focus Areas', value: 'Flicks, Tracking, Positioning' },
      ],
    },
  },
  {
    id: 'gaming-settings',
    name: 'Gaming Settings',
    iconName: 'Sliders',
    shortDescription:
      'Comprehensive in-game configuration presets for controls, auto-pickup priority, mini-map rotation, sound balance, and notification suppression.',
    fullDescription:
      'Eliminate micro-stutters and input lag by fine-tuning native in-game settings. Features optimal auto-pickup speeds, quick reload button placement, and sound equalizer balance for audible enemy footsteps.',
    version: 'v4.1.0',
    updatedDate: 'Sep 08, 2026',
    category: 'settings',
    downloadUrl: '#download-gaming-settings',
    fileSize: '1.9 MB',
    fileType: 'Settings Preset & Guide',
    downloadsCount: 9760,
    quickPreview: {
      summary: 'Clean in-game settings for zero distractions and rapid loot acquisition.',
      highlights: [
        'Auto-Pickup: Weapons & Ammo on Fast; Grenades on Manual to prevent clutter',
        'Mini-Map: Rotating with North indicator for precise callouts',
        'Damage Indicator: Classic / Yellow headshot font for high visibility',
        'Sound Effect Balance: SFX 100%, Music 0%, Voice Chat 65%',
      ],
      specs: [
        { label: 'Quick Reload', value: 'ON' },
        { label: 'Quick Weapon Switch', value: 'ON' },
        { label: 'Double Fire Button', value: 'ALWAYS' },
        { label: 'In-Game Tips', value: 'SIMPLIFIED' },
      ],
    },
  },
  {
    id: 'tournament-information',
    name: 'Tournament Information',
    iconName: 'Trophy',
    shortDescription:
      'Official competitive rulebook, scrim schedule directory, weapon ban-lists, drop-spot rotation heatmaps, and scrim scoring calculators.',
    fullDescription:
      'Stay updated on tier-1 and community competitive tournament regulations. Includes official point multipliers, banned gun attributes/character combinations, squad role breakdowns, and scrim registration links.',
    version: 'v2026.3',
    updatedDate: 'Sep 16, 2026',
    category: 'tournaments',
    downloadUrl: '#download-tournament-info',
    fileSize: '4.7 MB',
    fileType: 'Esports Handbook & Schedule',
    downloadsCount: 7120,
    badge: 'ESPORTS',
    quickPreview: {
      summary: 'Essential tournament survival handbook for competitive squads and team captains.',
      highlights: [
        'Official 2026 competitive scoring system (12 pts for #1, 1 pt per kill)',
        'Character skill restrictions and allowed active skill combos',
        'Zone rotation timings and safe shelter positioning heatmaps',
        'Scrim registration guidelines and dispute reporting workflow',
      ],
      specs: [
        { label: 'Format', value: 'Squad Battle Royale' },
        { label: 'Gun Attributes', value: 'Disabled (Pure Skill)' },
        { label: 'Map Pool', value: 'Bermuda, Purgatory, Kalahari' },
        { label: 'Match Count', value: '6 Matches per Day' },
      ],
    },
  },
  {
    id: 'game-updates',
    name: 'Game Updates',
    iconName: 'Sparkles',
    shortDescription:
      'Deep dive patch breakdown, weapon buffs/nerfs analysis, new character balance sheets, map changes, and meta tier rankings.',
    fullDescription:
      'Understand every balance adjustment before jumping into ranked games. Detailed stat comparisons for updated assault rifles, SMGs, and sniper reload times, plus counter strategies against newly buffed characters.',
    version: 'OB45 Patch',
    updatedDate: 'Sep 15, 2026',
    category: 'guides',
    downloadUrl: '#download-game-updates',
    fileSize: '3.1 MB',
    fileType: 'Patch Breakdown & Meta Sheet',
    downloadsCount: 13200,
    badge: 'LATEST PATCH',
    quickPreview: {
      summary: 'Full meta shifts, weapon rebalances, and mechanic updates for the newest season update.',
      highlights: [
        'MP40 & UMP fire-rate adjustments analysis',
        'Woodpecker damage dropoff distance changes',
        'Chrono cooldown update & Tatsuya dash optimization tips',
        'Supply drop loot tier revisions and new defensive items',
      ],
      specs: [
        { label: 'Current Patch', value: 'OB45 Global' },
        { label: 'Season Tier', value: 'Ranked Season 38' },
        { label: 'Meta Dominance', value: 'High Mobility SMG / Shotgun' },
      ],
    },
  },
  {
    id: 'graphics-settings',
    name: 'Graphics Settings',
    iconName: 'MonitorPlay',
    shortDescription:
      'Ultra smooth display config profiles for constant 60/90/120 FPS, shadows disable parameters, and device thermal optimization configs.',
    fullDescription:
      'Extract maximum smooth frame rates without overheating your device. Clear comparisons between Smooth, Standard, and Ultra modes with recommended filter choices (Vivid vs Classic) to spot enemies easily.',
    version: 'v3.8.0',
    updatedDate: 'Sep 12, 2026',
    category: 'settings',
    downloadUrl: '#download-graphics-settings',
    fileSize: '2.2 MB',
    fileType: 'FPS Optimization Guide',
    downloadsCount: 16900,
    badge: 'HIGH FPS',
    quickPreview: {
      summary: 'Maximum frame rate and thermal preservation presets for competitive gameplay.',
      highlights: [
        'Graphics: Smooth (Lowest texture overhead for instant touch feedback)',
        'High FPS: High / Max (Enables 60/90/120Hz unlocked refresh rate)',
        'Shadows: OFF (Prevents frame drops during chaotic squad fights)',
        'Filter: Vivid (Enhances player silhouettes against grassy terrain)',
      ],
      specs: [
        { label: 'Frame Rate', value: 'Unlocked 90 / 120 FPS' },
        { label: 'Battery Impact', value: 'Reduced by 22%' },
        { label: 'Thermal Throttling', value: 'Prevented' },
        { label: 'Visual Clarity', value: 'High Silhouette Contrast' },
      ],
    },
  },
  {
    id: 'performance-tips',
    name: 'Performance Tips',
    iconName: 'Zap',
    shortDescription:
      'System-level Android/iOS optimization: background process limitation, touch sampling rate increase, ping stabilization, and thermal management.',
    fullDescription:
      'Fix ghost touch, eliminate WiFi ping spikes, and maintain consistent peak touch sampling rates during intense combat. 100% legitimate OS setting tweaks requiring no root or unauthorized device modifications.',
    version: 'v5.0.1',
    updatedDate: 'Sep 17, 2026',
    category: 'performance',
    downloadUrl: '#download-performance-tips',
    fileSize: '3.9 MB',
    fileType: 'PDF Hardware & OS Guide',
    downloadsCount: 18450,
    badge: 'ESSENTIAL',
    quickPreview: {
      summary: 'Proven system-level tweaks to eliminate latency, frame drops, and touch delay.',
      highlights: [
        'Developer Options: Set Background Process Limit & turn off window animations',
        'Game Space / Game Turbo: Enable performance mode and touch response boost',
        'Network: Private DNS recommendation to bypass high ISP routing jitter',
        'Physical heat dissipation tips to avoid aggressive CPU throttling',
      ],
      specs: [
        { label: 'Touch Latency', value: '-18ms Improvement' },
        { label: 'Ping Stability', value: 'Smooth 20ms - 35ms avg' },
        { label: 'Device Safety', value: '100% Stock OS Native' },
        { label: 'Root Required?', value: 'NO (Safe for all users)' },
      ],
    },
  },
];
