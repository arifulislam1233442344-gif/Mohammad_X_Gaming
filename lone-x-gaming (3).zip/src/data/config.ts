import { SocialLink, FeaturedPromo, BannerSlide } from '../types';

export const SITE_CONFIG = {
  name: 'MOHAMMAD',
  subtitle: 'Made by Mohammad',
  tagline: 'Made by Mohammad',
  description:
    'Welcome to MOHAMMAD. Find gaming resources, guides, updates and useful files in one place.',
  owner: 'Mohammad',
  statusText: 'Patch OB45 Verified Safe',
  avatarImage: 'https://i.ibb.co/k2Ww1Q6J/Screenshot-20260918-230743.jpg',
  featuredBannerImage: 'https://i.ibb.co/ZRQYCgYt/images.jpg',
};

export const BANNER_SLIDES: BannerSlide[] = [
  {
    id: 'banner-1',
    image: 'https://i.ibb.co/ZRQYCgYt/images.jpg',
    title: 'MOHAMMAD FREE FIRE PRO SENSITIVITY & HEADSHOT CONFIG',
    subtitle: 'OB45 AUTO-AIM DRAG & ACCURACY MATRIX',
    badge: 'BANNER 1 • PRO SENSITIVITY',
    description:
      'Calibrated General, Red Dot, 2X, and 4X Scope DPI settings with optimized drag sensitivity timing for crisp, consistent one-tap headshots in ranked matches.',
    ctaText: 'GET SENSITIVITY PACK',
    resourceId: 'sensitivity-guide',
  },
  {
    id: 'banner-2',
    image: 'https://i.ibb.co/mryPNmqN/776d2b84f52ac9e99a856dab9beac1bf.jpg',
    title: 'FREE FIRE FAST GLOO WALL & 3/4-FINGER CLAW HUD',
    subtitle: 'ULTRA-FAST REFLEX COMBAT BLUEPRINT',
    badge: 'BANNER 2 • PRO CLAW HUD',
    description:
      'Custom tournament-tested HUD schematics for instantaneous 360° sit-up Gloo Wall defense, jump-shot trigger positioning, and zero-delay weapon switching.',
    ctaText: 'VIEW HUD LAYOUT',
    resourceId: 'hud-guide',
  },
  {
    id: 'banner-3',
    image: 'https://i.ibb.co/7NxbqkDW/images-1.jpg',
    title: 'FREE FIRE SEASON TOURNAMENT & META UPDATES',
    subtitle: 'OB45 WEAPON STATS & 120 FPS CONFIG',
    badge: 'BANNER 3 • META ARENA',
    description:
      'Comprehensive ranked tier list, weapon balance adjustments, drop-spot rotation heatmaps, and low-latency 90/120 FPS graphics presets for zero stutters.',
    ctaText: 'EXPLORE TOURNAMENT PACK',
    resourceId: 'tournament-information',
  },
];

export const SOCIAL_LINKS: SocialLink[] = [
  {
    id: 'tiktok',
    name: 'TikTok',
    url: 'https://www.tiktok.com/@skmohammed161?_r=1&_t=ZS-99q8vSdv26i',
    handle: '@skmohammed161',
    followers: 'Follow on TikTok',
    color: '#ff0050',
    glowColor: 'rgba(255, 0, 80, 0.4)',
    icon: 'Music2',
  },
  {
    id: 'youtube',
    name: 'YouTube',
    url: 'https://www.youtube.com/@Piku-Piku208',
    handle: '@Piku-Piku208',
    followers: 'Subscribe on YouTube',
    color: '#ff0000',
    glowColor: 'rgba(255, 0, 0, 0.4)',
    icon: 'Youtube',
  },
  {
    id: 'telegram',
    name: 'Telegram',
    url: 'https://t.me/OWNER_ARIFUL',
    handle: '@OWNER_ARIFUL',
    followers: 'Join Telegram Channel',
    color: '#229ed9',
    glowColor: 'rgba(34, 158, 217, 0.4)',
    icon: 'Send',
  },
];

export const FEATURED_PROMO: FeaturedPromo = {
  title: 'Official Season Championship & Pro Config Pack',
  tagline: 'ULTIMATE COMPETITIVE GUIDE • FREE FIRE EDITION',
  description:
    'Master high-ground rotation, headshot drag timing, optimized DPI sensitivities, and low-latency graphics presets tested by tournament finalists.',
  badge: 'FEATURED RELEASE',
  releaseDate: 'September 2026',
  bannerImage: '/src/assets/images/mohammad_banner_1789749351341.jpg',
  resourceId: 'sensitivity-guide',
  highlights: [
    'Complete calibrated General, Red Dot, 2X and 4X Scope settings',
    '3-Finger and 4-Finger Claw claw layout HUD coordinates',
    'Zero-frame drop 90FPS/120FPS graphics optimization',
    'Legitimate & 100% Anti-Ban compliant — No third-party injectors',
  ],
};
