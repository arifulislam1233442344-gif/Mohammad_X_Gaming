import React from 'react';
import { motion } from 'motion/react';
import {
  ExternalLink,
  Users,
  CheckCircle2,
  Bell,
  Send,
  Youtube,
  Facebook,
  Music2,
} from 'lucide-react';
import { SOCIAL_LINKS } from '../data/config';
import { SocialLink } from '../types';

interface SocialSectionProps {
  onCopyHandle: (handle: string) => void;
}

export const SocialSection: React.FC<SocialSectionProps> = ({ onCopyHandle }) => {
  const renderSocialIcon = (name: SocialLink['name']) => {
    switch (name) {
      case 'TikTok':
        return <Music2 className="w-5 h-5 text-white" />;
      case 'YouTube':
        return <Youtube className="w-5 h-5 text-white" />;
      case 'Telegram':
        return <Send className="w-5 h-5 text-white" />;
      default:
        return <Users className="w-5 h-5 text-white" />;
    }
  };

  return (
    <section id="social-section" className="py-10 sm:py-14 px-4 sm:px-6">
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-xl mx-auto mb-8 sm:mb-10 space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs font-bold uppercase tracking-wider">
            <Bell className="w-3.5 h-3.5 text-purple-400" />
            <span>Join the Community</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-black uppercase text-white tracking-wide font-['Orbitron',sans-serif]">
            Follow My Other Social Media
          </h2>
          <p className="text-sm text-zinc-400">
            Get daily sensitivity configs, patch update alerts, and gameplay clips directly on my official social channels.
          </p>
        </div>

        {/* 3 Social Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 max-w-4xl mx-auto gap-4">
          {SOCIAL_LINKS.map((social, index) => (
            <motion.div
              key={social.id}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.08 }}
              className="group relative p-5 rounded-2xl bg-zinc-900/70 hover:bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition-all duration-300 shadow-md flex flex-col justify-between"
            >
              <div>
                {/* Header row with icon & status */}
                <div className="flex items-center justify-between mb-4">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center shadow-lg transition-transform group-hover:scale-110 duration-300"
                    style={{ backgroundColor: social.color }}
                  >
                    {renderSocialIcon(social.name)}
                  </div>
                  <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Active</span>
                  </span>
                </div>

                {/* Social Name & Handle */}
                <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors">
                  {social.name}
                </h3>
                <p className="text-xs font-mono text-zinc-400 mt-0.5 truncate">
                  {social.handle}
                </p>

                {/* Followers count pill */}
                <div className="mt-3 flex items-center gap-1.5 text-xs text-zinc-300">
                  <Users className="w-3.5 h-3.5 text-zinc-500" />
                  <span className="font-semibold text-zinc-200">{social.followers}</span>
                </div>
              </div>

              {/* Action Button */}
              <div className="mt-5 pt-3 border-t border-zinc-800/80">
                <a
                  id={`social-link-btn-${social.id}`}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold text-white transition-all duration-200 active:scale-95 shadow-sm"
                  style={{
                    backgroundColor: social.color,
                  }}
                >
                  <span>Follow on {social.name}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
