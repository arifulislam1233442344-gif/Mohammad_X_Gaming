import React from 'react';
import { motion } from 'motion/react';
import {
  ShieldCheck,
  CheckCircle2,
  Download,
  Share2,
  ExternalLink,
} from 'lucide-react';
import { SITE_CONFIG, SOCIAL_LINKS } from '../data/config';

interface HeroSectionProps {
  onScrollToDownloads: () => void;
  onCopySiteLink: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onScrollToDownloads,
  onCopySiteLink,
}) => {
  return (
    <section
      id="hero-section"
      className="relative pt-8 pb-12 sm:pt-12 sm:pb-16 px-4 sm:px-6 overflow-hidden"
    >
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[340px] sm:w-[520px] h-[340px] sm:h-[520px] bg-gradient-to-tr from-cyan-500/15 via-purple-600/15 to-transparent rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-4xl mx-auto flex flex-col items-center text-center">
        {/* Profile Image with dual neon ring & pulse */}
        <motion.div
          initial={{ scale: 0.85, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          className="relative mb-5"
        >
          {/* Animated subtle outer halo */}
          <div className="absolute -inset-1.5 rounded-full bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 opacity-70 blur-md animate-pulse" />

          {/* Profile Circle Frame */}
          <div className="relative w-28 h-28 sm:w-36 sm:h-36 rounded-full p-1 bg-gradient-to-br from-cyan-400 via-purple-500 to-pink-500 shadow-xl shadow-cyan-500/20">
            <div className="w-full h-full rounded-full overflow-hidden bg-[#0a0b12] border-2 border-zinc-900">
              <img
                src={SITE_CONFIG.avatarImage}
                alt={`${SITE_CONFIG.name} Profile`}
                className="w-full h-full object-cover object-center"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Verified badge */}
            <div
              className="absolute bottom-1 right-1 w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-[#08090e] border-2 border-cyan-400 flex items-center justify-center text-cyan-400 shadow-md shadow-cyan-400/40"
              title="Verified Gaming Creator"
            >
              <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 fill-cyan-400 text-[#08090e]" />
            </div>
          </div>
        </motion.div>

        {/* Website Title */}
        <motion.div
          initial={{ y: 15, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.45, delay: 0.1 }}
          className="space-y-3"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900/90 border border-zinc-700/60 text-xs font-semibold text-zinc-300">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <span className="text-zinc-200">OFFICIAL PORTAL</span>
            <span className="text-zinc-600">•</span>
            <span className="text-cyan-400 font-mono">100% SAFE FILES</span>
          </div>

          <h1 className="text-3xl sm:text-5xl md:text-6xl font-black uppercase tracking-wider font-['Orbitron',sans-serif]">
            <span className="bg-gradient-to-r from-white via-cyan-200 to-purple-400 bg-clip-text text-transparent drop-shadow-sm">
              {SITE_CONFIG.name}
            </span>
          </h1>

          {/* Subtitle: Made by Mohammad */}
          <div className="flex items-center justify-center gap-2 pt-1">
            <span className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-gradient-to-r from-cyan-500/15 via-purple-500/15 to-cyan-500/15 border border-cyan-400/50 text-cyan-300 text-xs sm:text-sm font-extrabold tracking-widest uppercase font-['Orbitron',sans-serif] shadow-sm shadow-cyan-500/20">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              {SITE_CONFIG.subtitle}
            </span>
          </div>

          {/* Short description */}
          <p className="max-w-2xl mx-auto text-sm sm:text-base md:text-lg text-zinc-300 leading-relaxed font-normal pt-1">
            {SITE_CONFIG.description}
          </p>
        </motion.div>

        {/* Social Media Buttons (TikTok, YouTube, Telegram) */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.45, delay: 0.2 }}
          className="w-full max-w-xl mt-6 sm:mt-7"
        >
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3">
            {SOCIAL_LINKS.map((social) => (
              <a
                key={social.id}
                id={`hero-social-${social.id}`}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative flex items-center justify-between sm:justify-start gap-2.5 px-4 py-3 rounded-xl bg-zinc-900/85 hover:bg-zinc-800/90 border border-zinc-800 hover:border-zinc-600 text-zinc-200 hover:text-white transition-all duration-200 shadow-sm active:scale-95"
              >
                {/* Brand dot glow */}
                <div
                  className="w-2.5 h-2.5 rounded-full shrink-0 group-hover:scale-125 transition-transform"
                  style={{ backgroundColor: social.color }}
                />
                <span className="text-xs sm:text-sm font-bold tracking-wide">
                  {social.name}
                </span>
                <ExternalLink className="w-3.5 h-3.5 text-zinc-500 group-hover:text-zinc-300 ml-auto shrink-0" />
              </a>
            ))}
          </div>
        </motion.div>

        {/* Quick action buttons */}
        <motion.div
          initial={{ y: 15, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.45, delay: 0.25 }}
          className="flex flex-wrap items-center justify-center gap-3 mt-6 sm:mt-8"
        >
          <button
            id="hero-jump-downloads"
            onClick={onScrollToDownloads}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-bold text-sm tracking-wide shadow-lg shadow-cyan-500/25 active:scale-95 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Explore All Downloads</span>
          </button>

          <button
            id="hero-share-portal"
            onClick={onCopySiteLink}
            className="flex items-center gap-2 px-4 py-3 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-zinc-300 hover:text-white font-semibold text-sm active:scale-95 transition-all"
          >
            <Share2 className="w-4 h-4 text-cyan-400" />
            <span>Share Portal</span>
          </button>
        </motion.div>

        {/* Trust Badges */}
        <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 mt-7 text-xs text-zinc-400">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            <span>Safe & Legitimate Only</span>
          </div>
          <span className="text-zinc-700 hidden sm:inline">•</span>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>No Hacks / Anti-Ban Compliant</span>
          </div>
          <span className="text-zinc-700 hidden sm:inline">•</span>
          <div className="flex items-center gap-1.5">
            <span className="text-purple-400 font-bold">⚡</span>
            <span>Fast Instant Access</span>
          </div>
        </div>
      </div>
    </section>
  );
};
