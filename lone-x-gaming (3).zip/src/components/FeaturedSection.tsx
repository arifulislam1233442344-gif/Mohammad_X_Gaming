import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Eye, Download, CheckCircle2 } from 'lucide-react';
import { FEATURED_PROMO } from '../data/config';
import { ResourceItem } from '../types';

interface FeaturedSectionProps {
  onViewMore: (resourceId: string) => void;
  onDownload: (resource: ResourceItem) => void;
  featuredResource?: ResourceItem;
}

export const FeaturedSection: React.FC<FeaturedSectionProps> = ({
  onViewMore,
  onDownload,
  featuredResource,
}) => {
  return (
    <section id="featured-section" className="py-6 sm:py-10 px-4 sm:px-6">
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <div className="flex items-center justify-between mb-4 sm:mb-5">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <h2 className="text-lg sm:text-xl font-bold uppercase tracking-wider text-white font-['Orbitron',sans-serif]">
              Featured Resource
            </h2>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-purple-500/15 border border-purple-500/30 text-purple-300">
            Official Drop
          </span>
        </div>

        {/* Large Featured Gaming Banner Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="relative rounded-2xl overflow-hidden border border-zinc-800 hover:border-cyan-500/40 bg-zinc-950 transition-all duration-300 group shadow-2xl shadow-black/60"
        >
          {/* Banner Image Container */}
          <div className="relative w-full aspect-[16/9] sm:aspect-[21/9] max-h-[420px] overflow-hidden">
            <img
              src={FEATURED_PROMO.bannerImage}
              alt={FEATURED_PROMO.title}
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 brightness-85"
              referrerPolicy="no-referrer"
            />

            {/* Gradient Overlays for high readability */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#08090e] via-[#08090e]/75 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#08090e]/90 via-[#08090e]/50 to-transparent" />

            {/* Top Badge */}
            <div className="absolute top-4 left-4 sm:top-6 sm:left-6 flex items-center gap-2">
              <span className="px-3 py-1 rounded-md bg-cyan-500/90 text-black font-extrabold text-xs tracking-wider uppercase font-['Orbitron',sans-serif] shadow-lg shadow-cyan-500/30">
                {FEATURED_PROMO.badge}
              </span>
              <span className="px-2.5 py-1 rounded-md bg-black/60 backdrop-blur-md border border-zinc-700/80 text-zinc-300 text-xs font-medium">
                {FEATURED_PROMO.releaseDate}
              </span>
            </div>
          </div>

          {/* Banner Content Overlay */}
          <div className="relative -mt-24 sm:-mt-32 p-5 sm:p-8 z-10">
            <div className="max-w-2xl space-y-3">
              <p className="text-xs sm:text-sm font-bold tracking-widest text-cyan-400 uppercase font-['Orbitron',sans-serif]">
                {FEATURED_PROMO.tagline}
              </p>
              <h3 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight leading-snug">
                {FEATURED_PROMO.title}
              </h3>
              <p className="text-zinc-300 text-sm sm:text-base leading-relaxed line-clamp-3">
                {FEATURED_PROMO.description}
              </p>

              {/* Highlights pills */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
                {FEATURED_PROMO.highlights.map((highlight, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-2 text-xs text-zinc-300 bg-zinc-900/80 backdrop-blur-sm px-3 py-1.5 rounded-lg border border-zinc-800"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span className="truncate">{highlight}</span>
                  </div>
                ))}
              </div>

              {/* Action Buttons: View More + Download */}
              <div className="flex flex-wrap items-center gap-3 pt-3">
                <button
                  id="featured-view-more-btn"
                  onClick={() => onViewMore(FEATURED_PROMO.resourceId)}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-sm shadow-lg shadow-purple-600/30 transition-all active:scale-95"
                >
                  <Eye className="w-4 h-4" />
                  <span>View More</span>
                </button>

                {featuredResource && (
                  <button
                    id="featured-download-btn"
                    onClick={() => onDownload(featuredResource)}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold text-sm tracking-wide shadow-lg shadow-cyan-500/25 transition-all active:scale-95"
                  >
                    <Download className="w-4 h-4" />
                    <span>DOWNLOAD PACK</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
