import React from 'react';
import {
  Crosshair,
  LayoutGrid,
  Target,
  Sliders,
  Trophy,
  Sparkles,
  MonitorPlay,
  Zap,
  Download,
  Calendar,
  Eye,
  ShieldCheck,
  FileText,
  Flame,
} from 'lucide-react';
import { ResourceItem } from '../types';

interface ResourceCardProps {
  resource: ResourceItem;
  onDownload: (resource: ResourceItem) => void;
  onPreview: (resource: ResourceItem) => void;
}

// Icon mapper for safe dynamic lookup
const renderResourceIcon = (iconName: string) => {
  const iconProps = { className: 'w-5 h-5 text-cyan-400' };
  switch (iconName) {
    case 'Crosshair':
      return <Crosshair {...iconProps} />;
    case 'LayoutGrid':
      return <LayoutGrid {...iconProps} />;
    case 'Target':
      return <Target {...iconProps} />;
    case 'Sliders':
      return <Sliders {...iconProps} />;
    case 'Trophy':
      return <Trophy {...iconProps} />;
    case 'Sparkles':
      return <Sparkles {...iconProps} />;
    case 'MonitorPlay':
      return <MonitorPlay {...iconProps} />;
    case 'Zap':
      return <Zap {...iconProps} />;
    default:
      return <FileText {...iconProps} />;
  }
};

export const ResourceCard: React.FC<ResourceCardProps> = ({
  resource,
  onDownload,
  onPreview,
}) => {
  return (
    <div
      id={`resource-card-${resource.id}`}
      className="group relative flex flex-col justify-between p-4 sm:p-5 rounded-2xl bg-zinc-900/70 hover:bg-zinc-900 border border-zinc-800 hover:border-cyan-500/50 transition-all duration-300 shadow-lg shadow-black/40 hover:shadow-cyan-500/10"
    >
      {/* Top row: Icon + Name + Badge */}
      <div>
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-3">
            {/* Icon Container with subtle neon rim */}
            <div className="w-10 h-10 rounded-xl bg-[#08090e] border border-cyan-500/30 flex items-center justify-center group-hover:scale-105 group-hover:border-cyan-400 transition-all shadow-sm">
              {renderResourceIcon(resource.iconName)}
            </div>

            <div>
              <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-cyan-300 transition-colors leading-tight">
                {resource.name}
              </h3>
              {/* Version & Date tag */}
              <div className="flex items-center gap-2 mt-1 text-[11px] text-zinc-400 font-medium">
                <span className="px-1.5 py-0.5 rounded bg-zinc-800 text-cyan-300 font-mono font-semibold">
                  {resource.version}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-zinc-500" />
                  <span>{resource.updatedDate}</span>
                </span>
              </div>
            </div>
          </div>

          {/* Optional Badge */}
          {resource.badge && (
            <span
              className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md border tracking-wider shrink-0 font-['Orbitron',sans-serif] ${
                resource.badge.includes('TOP') || resource.badge.includes('POPULAR')
                  ? 'bg-pink-500/15 border-pink-500/40 text-pink-400'
                  : resource.badge.includes('RECOMMENDED') || resource.badge.includes('LATEST')
                  ? 'bg-purple-500/15 border-purple-500/40 text-purple-300'
                  : 'bg-cyan-500/15 border-cyan-500/40 text-cyan-300'
              }`}
            >
              {resource.badge}
            </span>
          )}
        </div>

        {/* Short Description */}
        <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed line-clamp-3 mb-4">
          {resource.shortDescription}
        </p>
      </div>

      {/* Card Footer: Metadata info + DOWNLOAD Action */}
      <div className="pt-3 border-t border-zinc-800/80 space-y-3">
        {/* Meta Stats Row */}
        <div className="flex items-center justify-between text-[11px] text-zinc-400">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-zinc-400">Clean & Safe</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-zinc-400">{resource.fileSize}</span>
            <span className="text-zinc-600">•</span>
            <span className="text-zinc-400 flex items-center gap-1">
              <Flame className="w-3 h-3 text-cyan-400" />
              {resource.downloadsCount.toLocaleString()} DLs
            </span>
          </div>
        </div>

        {/* Button Actions: Preview + DOWNLOAD */}
        <div className="grid grid-cols-5 gap-2">
          {/* Quick Preview button */}
          <button
            id={`btn-preview-${resource.id}`}
            onClick={() => onPreview(resource)}
            className="col-span-2 flex items-center justify-center gap-1.5 py-2 px-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700/80 border border-zinc-700/80 text-zinc-200 hover:text-white text-xs font-semibold active:scale-95 transition-all"
            title="Read online summary"
          >
            <Eye className="w-3.5 h-3.5 text-cyan-400" />
            <span>Preview</span>
          </button>

          {/* Primary DOWNLOAD Button requested */}
          <button
            id={`btn-download-${resource.id}`}
            onClick={() => onDownload(resource)}
            className="col-span-3 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-gradient-to-r from-cyan-500 via-cyan-400 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-black font-extrabold text-xs sm:text-sm tracking-wider uppercase font-['Orbitron',sans-serif] shadow-md shadow-cyan-500/20 active:scale-95 transition-all"
          >
            <Download className="w-4 h-4 text-black stroke-[2.5]" />
            <span>DOWNLOAD</span>
          </button>
        </div>
      </div>
    </div>
  );
};
