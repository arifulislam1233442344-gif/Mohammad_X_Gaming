import React, { useState, useEffect } from 'react';
import {
  X,
  Download,
  ShieldCheck,
  FileCheck,
  Copy,
  Check,
  ExternalLink,
  HardDrive,
  Clock,
  Sparkles,
  AlertCircle,
} from 'lucide-react';
import { ResourceItem } from '../types';
import { SITE_CONFIG } from '../data/config';

interface DownloadModalProps {
  resource: ResourceItem | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenGuideViewer: (resource: ResourceItem) => void;
  onNotify: (msg: string) => void;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({
  resource,
  isOpen,
  onClose,
  onOpenGuideViewer,
  onNotify,
}) => {
  const [countdown, setCountdown] = useState<number>(3);
  const [isReady, setIsReady] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [downloadStarted, setDownloadStarted] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen && resource) {
      setCountdown(3);
      setIsReady(false);
      setCopied(false);
      setDownloadStarted(false);

      const timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            setIsReady(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [isOpen, resource]);

  if (!isOpen || !resource) return null;

  const handleTriggerDownload = () => {
    setDownloadStarted(true);
    onNotify(`Download initiated for ${resource.name}!`);

    // Simulate clean file download trigger using blob/placeholder
    const element = document.createElement('a');
    const dummyContent = `${SITE_CONFIG.name} OFFICIAL RESOURCE (${SITE_CONFIG.subtitle})
Title: ${resource.name}
Version: ${resource.version}
Updated: ${resource.updatedDate}
Safety: Verified Clean & Anti-Ban Compliant

--- SUMMARY ---
${resource.shortDescription}

--- QUICK PREVIEW HIGHLIGHTS ---
${resource.quickPreview?.highlights.join('\n') || 'Official guides and settings.'}

Visit ${SITE_CONFIG.name} (${SITE_CONFIG.subtitle}) for updates!`;

    const file = new Blob([dummyContent], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = `${SITE_CONFIG.name}_${resource.name.replace(/\s+/g, '_')}_${resource.version}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(
      `${window.location.origin}/#${resource.id}`
    );
    setCopied(true);
    onNotify('Direct resource link copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      id="download-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div
        id="download-modal-container"
        className="relative w-full max-w-lg rounded-2xl bg-[#0d0e15] border border-cyan-500/30 p-5 sm:p-7 shadow-2xl shadow-cyan-500/10 text-white"
      >
        {/* Close Button */}
        <button
          id="close-download-modal"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          aria-label="Close modal"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5 pr-8">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-cyan-500/20 to-purple-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shrink-0">
            <Download className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 uppercase tracking-wider font-['Orbitron',sans-serif]">
                Verified File
              </span>
              <span className="text-xs text-zinc-400 font-mono">
                {resource.version}
              </span>
            </div>
            <h3 className="text-xl font-bold text-white leading-tight mt-0.5">
              {resource.name}
            </h3>
          </div>
        </div>

        {/* File Attributes Grid */}
        <div className="grid grid-cols-3 gap-2.5 p-3 rounded-xl bg-zinc-900/80 border border-zinc-800 text-xs mb-5">
          <div className="space-y-0.5">
            <span className="text-zinc-400 flex items-center gap-1">
              <HardDrive className="w-3 h-3 text-zinc-500" /> Size
            </span>
            <p className="font-bold text-zinc-200">{resource.fileSize}</p>
          </div>
          <div className="space-y-0.5">
            <span className="text-zinc-400 flex items-center gap-1">
              <FileCheck className="w-3 h-3 text-zinc-500" /> Type
            </span>
            <p className="font-bold text-zinc-200 truncate">{resource.fileType}</p>
          </div>
          <div className="space-y-0.5">
            <span className="text-zinc-400 flex items-center gap-1">
              <Clock className="w-3 h-3 text-zinc-500" /> Updated
            </span>
            <p className="font-bold text-zinc-200">{resource.updatedDate}</p>
          </div>
        </div>

        {/* Security / Anti-Cheat Compliance Badge */}
        <div className="flex items-start gap-2.5 p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-emerald-300 text-xs mb-5">
          <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-emerald-300">
              Legitimate & Anti-Ban Verified
            </p>
            <p className="text-[11px] text-emerald-400/80 mt-0.5 leading-snug">
              100% safe native configurations, guides, and layouts. Guaranteed zero third-party hacks, injectors, or security bypasses.
            </p>
          </div>
        </div>

        {/* Download Countdown or Button */}
        <div className="space-y-3">
          {!isReady ? (
            <div className="w-full py-3.5 px-4 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center gap-2 text-zinc-400 text-sm font-semibold">
              <div className="w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
              <span>Verifying server link... ready in {countdown}s</span>
            </div>
          ) : (
            <button
              id="confirm-download-action-btn"
              onClick={handleTriggerDownload}
              className={`w-full py-3.5 px-6 rounded-xl font-extrabold text-sm uppercase tracking-wider font-['Orbitron',sans-serif] flex items-center justify-center gap-2 transition-all active:scale-98 shadow-lg ${
                downloadStarted
                  ? 'bg-emerald-500 text-black shadow-emerald-500/25'
                  : 'bg-gradient-to-r from-cyan-400 via-cyan-500 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black shadow-cyan-500/30'
              }`}
            >
              {downloadStarted ? (
                <>
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>Download Started! (Click to re-save)</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 stroke-[3]" />
                  <span>DOWNLOAD NOW ({resource.fileSize})</span>
                </>
              )}
            </button>
          )}

          {/* Secondary Actions: Quick Preview & Copy Link */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              id="modal-view-guide-btn"
              onClick={() => {
                onClose();
                onOpenGuideViewer(resource);
              }}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs font-semibold text-zinc-300 hover:text-white transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>Read Online Guide</span>
            </button>

            <button
              id="modal-copy-link-btn"
              onClick={handleCopyLink}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs font-semibold text-zinc-300 hover:text-white transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="text-cyan-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-zinc-400" />
                  <span>Copy Link</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Small note */}
        <p className="text-[11px] text-zinc-400 text-center mt-4">
          Free direct link with high-speed CDN routing. No registration required.
        </p>
      </div>
    </div>
  );
};
