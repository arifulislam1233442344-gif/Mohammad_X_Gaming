import React from 'react';
import { ShieldCheck, Flame, ArrowUpRight } from 'lucide-react';
import { SITE_CONFIG } from '../data/config';

interface HeaderProps {
  onScrollToSection: (sectionId: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onScrollToSection }) => {
  return (
    <header
      id="main-header"
      className="sticky top-0 z-40 w-full backdrop-blur-md bg-[#08090e]/85 border-b border-zinc-800/80 transition-all duration-200"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand identity */}
        <button
          id="header-brand-btn"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="flex items-center gap-3 group text-left focus:outline-none"
        >
          <div className="relative w-9 h-9 rounded-full overflow-hidden p-0.5 bg-gradient-to-tr from-cyan-500 via-purple-500 to-pink-500 group-hover:scale-105 transition-transform duration-300">
            <img
              src={SITE_CONFIG.avatarImage}
              alt={SITE_CONFIG.name}
              className="w-full h-full rounded-full object-cover bg-black"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold tracking-wider text-sm sm:text-base text-white group-hover:text-cyan-400 transition-colors uppercase font-['Orbitron',sans-serif]">
                {SITE_CONFIG.name}
              </span>
              <span className="inline-flex items-center px-1.5 py-0.2 text-[10px] font-bold rounded-sm bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                PRO
              </span>
            </div>
            <p className="text-[11px] text-cyan-400/90 font-medium hidden sm:block">
              {SITE_CONFIG.subtitle}
            </p>
          </div>
        </button>

        {/* Navigation & Actions */}
        <div className="flex items-center gap-2 sm:gap-4">
          <nav className="hidden md:flex items-center gap-1 text-sm font-medium">
            <button
              id="nav-banner-btn"
              onClick={() => onScrollToSection('banner-section')}
              className="px-3 py-1.5 rounded-lg text-zinc-300 hover:text-white hover:bg-zinc-800/60 transition-colors"
            >
              Banners
            </button>
            <button
              id="nav-resources-btn"
              onClick={() => onScrollToSection('resources-section')}
              className="px-3 py-1.5 rounded-lg text-zinc-300 hover:text-white hover:bg-zinc-800/60 transition-colors"
            >
              Downloads
            </button>
            <button
              id="nav-social-btn"
              onClick={() => onScrollToSection('social-section')}
              className="px-3 py-1.5 rounded-lg text-zinc-300 hover:text-white hover:bg-zinc-800/60 transition-colors"
            >
              Community
            </button>
          </nav>

          {/* Safe Badge pill */}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Anti-Ban 100%</span>
          </div>

          {/* Quick jump to downloads */}
          <button
            id="header-cta-download"
            onClick={() => onScrollToSection('resources-section')}
            className="flex items-center gap-1.5 px-3 sm:px-4 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-cyan-500/20 transition-all active:scale-95"
          >
            <Flame className="w-3.5 h-3.5 text-cyan-200" />
            <span>Get Files</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
