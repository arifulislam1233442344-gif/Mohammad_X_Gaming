import React from 'react';
import { ArrowUp, ShieldCheck, Heart, Sparkles } from 'lucide-react';
import { SITE_CONFIG } from '../data/config';
import { PolicyModalType } from './PolicyModal';

interface FooterProps {
  onOpenPolicy: (type: PolicyModalType) => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenPolicy }) => {
  const handleScrollTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer
      id="main-footer"
      className="border-t border-zinc-800/80 bg-[#06070b] pt-12 pb-8 px-4 sm:px-6 text-zinc-400 text-xs"
    >
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-zinc-800/60">
          {/* Brand Info */}
          <div className="flex flex-col items-center md:items-start text-center md:text-left space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full overflow-hidden border border-cyan-400">
                <img
                  src={SITE_CONFIG.avatarImage}
                  alt={SITE_CONFIG.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <span className="font-extrabold text-white text-base tracking-wider uppercase font-['Orbitron',sans-serif]">
                {SITE_CONFIG.name}
              </span>
              <span className="text-xs text-cyan-400 font-semibold">• {SITE_CONFIG.subtitle}</span>
            </div>
            <p className="text-zinc-500 max-w-md">
              High-performance Free Fire & mobile gaming resource portal. Tested sensitivities, custom claw HUD blueprints, and competitive guides.
            </p>
          </div>

          {/* Links from requirements: Privacy Policy, Disclaimer, Contact */}
          <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 font-medium text-sm">
            <button
              id="footer-privacy-btn"
              onClick={() => onOpenPolicy('privacy')}
              className="text-zinc-400 hover:text-cyan-400 transition-colors"
            >
              Privacy Policy
            </button>
            <span className="text-zinc-700">•</span>
            <button
              id="footer-disclaimer-btn"
              onClick={() => onOpenPolicy('disclaimer')}
              className="text-zinc-400 hover:text-amber-400 transition-colors"
            >
              Disclaimer
            </button>
            <span className="text-zinc-700">•</span>
            <button
              id="footer-contact-btn"
              onClick={() => onOpenPolicy('contact')}
              className="text-zinc-400 hover:text-purple-400 transition-colors"
            >
              Contact
            </button>
          </div>

          {/* Back to top button */}
          <button
            id="footer-back-to-top-btn"
            onClick={handleScrollTop}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white transition-all active:scale-95 text-xs font-semibold"
            title="Scroll to top"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5 text-cyan-400" />
          </button>
        </div>

        {/* Bottom row: Copyright & Fair Play notice */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-zinc-500">
          <div className="flex items-center gap-1.5 text-center sm:text-left">
            <span>© {new Date().getFullYear()} {SITE_CONFIG.name} • {SITE_CONFIG.subtitle}. All rights reserved.</span>
          </div>

          <div className="flex items-center gap-2 text-zinc-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Fair Play Safe Zone • 100% Anti-Ban Guarantee</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
