import React from 'react';
import { CheckCircle, Info } from 'lucide-react';

interface ToastProps {
  message: string | null;
  onDismiss: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, onDismiss }) => {
  if (!message) return null;

  return (
    <div
      id="global-toast-notification"
      className="fixed bottom-5 right-5 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl bg-zinc-900/95 border border-cyan-500/50 text-white text-xs sm:text-sm font-semibold shadow-xl shadow-cyan-500/20 backdrop-blur-md animate-in slide-in-from-bottom-5 duration-300"
    >
      <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0" />
      <span>{message}</span>
    </div>
  );
};
