import React from 'react';
import { X, Shield, AlertTriangle, Mail, Send, Check } from 'lucide-react';
import { SITE_CONFIG } from '../data/config';

export type PolicyModalType = 'privacy' | 'disclaimer' | 'contact' | null;

interface PolicyModalProps {
  type: PolicyModalType;
  isOpen: boolean;
  onClose: () => void;
  onNotify: (msg: string) => void;
}

export const PolicyModal: React.FC<PolicyModalProps> = ({
  type,
  isOpen,
  onClose,
  onNotify,
}) => {
  const [contactSubmitted, setContactSubmitted] = React.useState(false);
  const [contactEmail, setContactEmail] = React.useState('');
  const [contactMsg, setContactMsg] = React.useState('');

  if (!isOpen || !type) return null;

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactEmail.trim() || !contactMsg.trim()) return;
    setContactSubmitted(true);
    onNotify('Thank you! Your message has been sent to LONE-X GAMING.');
    setTimeout(() => {
      setContactSubmitted(false);
      setContactEmail('');
      setContactMsg('');
      onClose();
    }, 2000);
  };

  return (
    <div
      id="policy-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div
        id="policy-modal-container"
        className="relative w-full max-w-lg max-h-[85vh] flex flex-col rounded-2xl bg-[#0d0e16] border border-zinc-800 p-6 text-white shadow-2xl overflow-hidden"
      >
        {/* Close Button */}
        <button
          id="close-policy-modal"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Privacy Policy */}
        {type === 'privacy' && (
          <div className="space-y-4 overflow-y-auto pr-1">
            <div className="flex items-center gap-2.5 text-cyan-400">
              <Shield className="w-5 h-5" />
              <h3 className="text-xl font-bold uppercase font-['Orbitron',sans-serif]">
                Privacy Policy
              </h3>
            </div>
            <p className="text-xs text-zinc-400">
              Last updated: September 2026
            </p>
            <div className="space-y-3 text-xs sm:text-sm text-zinc-300 leading-relaxed">
              <p>
                At <strong className="text-white">{SITE_CONFIG.name}</strong>, user privacy is our highest priority. We believe in open, secure access to gaming guides without unnecessary data collection.
              </p>
              <h4 className="font-bold text-white text-xs uppercase tracking-wider font-['Orbitron',sans-serif]">
                Information We Do Not Collect
              </h4>
              <p>
                We do not ask for player game passwords, authentication tokens, payment details, or personal sensitive identification. All resource guides and configurations are hosted freely for educational and gameplay improvement purposes.
              </p>
              <h4 className="font-bold text-white text-xs uppercase tracking-wider font-['Orbitron',sans-serif]">
                Cookies & Local Storage
              </h4>
              <p>
                This site only uses minimal client-side browser storage to remember your sorting preferences and saved guides. No third-party tracking scripts sell your browsing habits.
              </p>
              <h4 className="font-bold text-white text-xs uppercase tracking-wider font-['Orbitron',sans-serif]">
                External Links
              </h4>
              <p>
                Our portal includes links to official social platforms (YouTube, TikTok, Telegram). Please refer to the privacy policies of those individual platforms when visiting them.
              </p>
            </div>
          </div>
        )}

        {/* Disclaimer */}
        {type === 'disclaimer' && (
          <div className="space-y-4 overflow-y-auto pr-1">
            <div className="flex items-center gap-2.5 text-amber-400">
              <AlertTriangle className="w-5 h-5" />
              <h3 className="text-xl font-bold uppercase font-['Orbitron',sans-serif]">
                Disclaimer & Fair Play
              </h3>
            </div>
            <div className="space-y-3 text-xs sm:text-sm text-zinc-300 leading-relaxed">
              <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs">
                <strong>Fair Play Notice:</strong> {SITE_CONFIG.name} is an independent community gaming portal dedicated strictly to fair gameplay, official game settings, and skill-improvement guides.
              </div>
              <p>
                <strong>No Cheats or Hacks:</strong> We strictly oppose and do NOT provide, host, or link to any aimbots, wallhacks, diamond generators, script injectors, APK modifications, or account manipulation tools.
              </p>
              <p>
                <strong>Trademarks:</strong> All game names, character artwork, logos, and trademarks (including Garena Free Fire) belong to their respective copyright holders. {SITE_CONFIG.name} is not officially affiliated with or endorsed by game developers or publishers.
              </p>
              <p>
                <strong>Educational Use:</strong> All sensitivity guides, claw HUD layouts, and graphics recommendations are based on publicly accessible in-game settings designed to help players enhance their legitimate skills safely without risk of ban.
              </p>
            </div>
          </div>
        )}

        {/* Contact Form */}
        {type === 'contact' && (
          <div className="space-y-4 overflow-y-auto pr-1">
            <div className="flex items-center gap-2.5 text-purple-400">
              <Mail className="w-5 h-5" />
              <h3 className="text-xl font-bold uppercase font-['Orbitron',sans-serif]">
                Contact {SITE_CONFIG.name}
              </h3>
            </div>
            <p className="text-xs text-zinc-400">
              Have questions, sponsorship inquiries, or resource suggestions? Leave a message below or reach out directly on Telegram.
            </p>

            {contactSubmitted ? (
              <div className="p-6 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-center space-y-2">
                <div className="w-10 h-10 rounded-full bg-emerald-500 text-black flex items-center justify-center mx-auto">
                  <Check className="w-5 h-5 stroke-[3]" />
                </div>
                <h4 className="font-bold text-white text-base">Message Sent!</h4>
                <p className="text-xs text-emerald-300">
                  We usually respond within 24 hours via email or community channels.
                </p>
              </div>
            ) : (
              <form onSubmit={handleContactSubmit} className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Your Email
                  </label>
                  <input
                    type="email"
                    required
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                    placeholder="player@example.com"
                    className="w-full px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-white text-xs focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Message / Inquiry
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={contactMsg}
                    onChange={(e) => setContactMsg(e.target.value)}
                    placeholder="Suggest a guide, report a broken link, or tournament partnership..."
                    className="w-full px-3.5 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-white text-xs focus:outline-none focus:border-cyan-400 resize-none"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-bold text-xs uppercase tracking-wider font-['Orbitron',sans-serif] flex items-center justify-center gap-2 active:scale-98 transition-all"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Message</span>
                </button>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
