import React from 'react';
import {
  X,
  Download,
  CheckCircle2,
  Sliders,
  ShieldCheck,
  Bookmark,
  Share2,
} from 'lucide-react';
import { ResourceItem } from '../types';

interface GuideViewerModalProps {
  resource: ResourceItem | null;
  isOpen: boolean;
  onClose: () => void;
  onTriggerDownload: (resource: ResourceItem) => void;
  onNotify: (msg: string) => void;
}

export const GuideViewerModal: React.FC<GuideViewerModalProps> = ({
  resource,
  isOpen,
  onClose,
  onTriggerDownload,
  onNotify,
}) => {
  if (!isOpen || !resource) return null;

  return (
    <div
      id="guide-viewer-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div
        id="guide-viewer-container"
        className="relative w-full max-w-2xl max-h-[90vh] flex flex-col rounded-2xl bg-[#0b0c14] border border-purple-500/40 shadow-2xl shadow-purple-500/10 text-white overflow-hidden"
      >
        {/* Modal Top Bar */}
        <div className="p-5 border-b border-zinc-800 flex items-center justify-between bg-zinc-950/60 shrink-0">
          <div className="flex items-center gap-2.5">
            <span className="p-1.5 rounded-lg bg-purple-500/15 text-purple-400 border border-purple-500/30">
              <Sliders className="w-4 h-4" />
            </span>
            <div>
              <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-widest font-['Orbitron',sans-serif]">
                In-Depth Overview
              </span>
              <h3 className="text-lg font-bold text-white leading-tight">
                {resource.name}
              </h3>
            </div>
          </div>

          <button
            id="close-guide-viewer-btn"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 text-sm text-zinc-300">
          {/* Overview text */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400 font-['Orbitron',sans-serif]">
              Summary & Purpose
            </h4>
            <p className="text-zinc-200 leading-relaxed">
              {resource.fullDescription || resource.shortDescription}
            </p>
          </div>

          {/* Quick preview highlights */}
          {resource.quickPreview && (
            <div className="space-y-3 p-4 rounded-xl bg-zinc-900/80 border border-zinc-800">
              <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-300 font-['Orbitron',sans-serif] flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                <span>Recommended Setup Highlights</span>
              </h4>
              <ul className="space-y-2">
                {resource.quickPreview.highlights.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-zinc-200">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-2 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Specs / Calibration Table */}
          {resource.quickPreview?.specs && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-purple-300 font-['Orbitron',sans-serif]">
                Calibration Matrix & Metrics
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {resource.quickPreview.specs.map((spec, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-3 rounded-xl bg-zinc-900/60 border border-zinc-800/80 text-xs"
                  >
                    <span className="text-zinc-400">{spec.label}</span>
                    <span className="font-bold text-white font-mono bg-zinc-800/80 px-2 py-0.5 rounded">
                      {spec.value}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Compliance & Safety Guarantee */}
          <div className="p-3.5 rounded-xl bg-zinc-900/40 border border-zinc-800 text-xs flex items-center justify-between text-zinc-400">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Full compliance with game Terms of Service</span>
            </div>
            <span className="text-emerald-400 font-bold font-mono">100% Native</span>
          </div>
        </div>

        {/* Modal Bottom Bar */}
        <div className="p-4 sm:p-5 border-t border-zinc-800 bg-zinc-950/90 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-zinc-400">
            Version <span className="text-zinc-200 font-mono font-bold">{resource.version}</span> • {resource.fileSize}
          </div>

          <div className="flex items-center gap-2">
            <button
              id="guide-viewer-close-btn"
              onClick={onClose}
              className="px-3.5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 text-xs font-bold transition-colors"
            >
              Close
            </button>
            <button
              id="guide-viewer-download-now-btn"
              onClick={() => {
                onClose();
                onTriggerDownload(resource);
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white text-xs font-bold uppercase tracking-wider font-['Orbitron',sans-serif] shadow-md shadow-cyan-500/20 active:scale-95 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download File</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
