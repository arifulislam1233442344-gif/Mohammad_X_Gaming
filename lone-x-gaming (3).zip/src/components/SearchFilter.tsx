import React from 'react';
import { Search, X, SlidersHorizontal, ArrowUpDown } from 'lucide-react';
import { ResourceCategory } from '../types';

interface SearchFilterProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCategory: ResourceCategory;
  onCategoryChange: (cat: ResourceCategory) => void;
  sortBy: 'latest' | 'popular' | 'size';
  onSortChange: (sort: 'latest' | 'popular' | 'size') => void;
  totalCount: number;
}

const CATEGORIES: { id: ResourceCategory; label: string }[] = [
  { id: 'all', label: 'All Resources' },
  { id: 'guides', label: 'Pro Guides' },
  { id: 'hud', label: 'HUD & Sensitivity' },
  { id: 'settings', label: 'Game Settings' },
  { id: 'performance', label: 'Performance & FPS' },
  { id: 'tournaments', label: 'Tournaments' },
];

export const SearchFilter: React.FC<SearchFilterProps> = ({
  searchQuery,
  onSearchChange,
  selectedCategory,
  onCategoryChange,
  sortBy,
  onSortChange,
  totalCount,
}) => {
  return (
    <div id="search-filter-section" className="space-y-4">
      {/* Search and Sort Row */}
      <div className="flex flex-col sm:flex-row gap-3">
        {/* Search Bar */}
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400 pointer-events-none" />
          <input
            id="resource-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search guides, HUD layouts, sensitivity, FPS settings..."
            className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-zinc-900/90 border border-zinc-800 focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 text-white placeholder-zinc-500 text-sm transition-all focus:outline-none"
          />
          {searchQuery && (
            <button
              id="clear-search-btn"
              onClick={() => onSearchChange('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
              title="Clear search"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Sort Selector */}
        <div className="flex items-center gap-2 self-end sm:self-auto shrink-0 w-full sm:w-auto">
          <div className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-zinc-900/90 border border-zinc-800 text-xs text-zinc-300 w-full sm:w-auto justify-between sm:justify-start">
            <div className="flex items-center gap-1.5 text-zinc-400">
              <ArrowUpDown className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sort:</span>
            </div>
            <div className="flex items-center gap-1">
              <button
                id="sort-latest-btn"
                onClick={() => onSortChange('latest')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                  sortBy === 'latest'
                    ? 'bg-cyan-500 text-black shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Latest
              </button>
              <button
                id="sort-popular-btn"
                onClick={() => onSortChange('popular')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                  sortBy === 'popular'
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Popular
              </button>
              <button
                id="sort-size-btn"
                onClick={() => onSortChange('size')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                  sortBy === 'size'
                    ? 'bg-zinc-700 text-white'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Size
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Category Filter Pills (Scrollable on mobile) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        <SlidersHorizontal className="w-4 h-4 text-zinc-500 shrink-0 hidden sm:block mr-1" />
        {CATEGORIES.map((cat) => {
          const isActive = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              id={`cat-filter-${cat.id}`}
              onClick={() => onCategoryChange(cat.id)}
              className={`whitespace-nowrap px-3.5 py-1.5 rounded-full text-xs font-bold tracking-wide transition-all shrink-0 active:scale-95 ${
                isActive
                  ? 'bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border border-cyan-400/80 text-cyan-300 shadow-sm shadow-cyan-500/20'
                  : 'bg-zinc-900/80 hover:bg-zinc-800/90 border border-zinc-800 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {cat.label}
            </button>
          );
        })}

        <div className="ml-auto text-xs text-zinc-400 hidden md:block shrink-0">
          Showing <span className="text-cyan-400 font-bold">{totalCount}</span> resources
        </div>
      </div>
    </div>
  );
};
