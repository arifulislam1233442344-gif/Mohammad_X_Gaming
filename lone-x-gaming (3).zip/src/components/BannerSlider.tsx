import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ChevronLeft,
  ChevronRight,
  Download,
  Eye,
  Flame,
  Pause,
  Play,
  Sparkles,
  Zap,
} from 'lucide-react';
import { BANNER_SLIDES } from '../data/config';
import { ResourceItem } from '../types';

interface BannerSliderProps {
  onActionClick: (resourceId: string) => void;
  onDownloadClick: (resource: ResourceItem) => void;
  findResourceById: (id: string) => ResourceItem | undefined;
}

export const BannerSlider: React.FC<BannerSliderProps> = ({
  onActionClick,
  onDownloadClick,
  findResourceById,
}) => {
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const touchStartX = useRef<number | null>(null);

  const currentSlide = BANNER_SLIDES[currentIndex];

  // Auto-slide effect strictly every 5 seconds (5000ms)
  useEffect(() => {
    if (isPaused) return;

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % BANNER_SLIDES.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [isPaused]);

  const handlePrev = () => {
    setCurrentIndex(
      (prev) => (prev - 1 + BANNER_SLIDES.length) % BANNER_SLIDES.length
    );
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % BANNER_SLIDES.length);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchStartX.current - touchEndX;

    if (diff > 50) {
      handleNext();
    } else if (diff < -50) {
      handlePrev();
    }
    touchStartX.current = null;
  };

  const currentResource = findResourceById(currentSlide.resourceId);

  return (
    <section
      id="banner-section"
      className="py-6 sm:py-10 px-4 sm:px-6 max-w-5xl mx-auto w-full"
    >
      {/* Section Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-gradient-to-br from-cyan-500/20 to-purple-600/20 border border-cyan-500/30 text-cyan-400 shadow-sm shadow-cyan-500/10">
            <Flame className="w-4 h-4 text-cyan-400" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-black uppercase tracking-wider text-white font-['Orbitron',sans-serif]">
              Free Fire Gaming Banners
            </h2>
            <p className="text-xs text-zinc-400 hidden sm:block">
              Auto-playing every 5 seconds • Updates & Pro Guides
            </p>
          </div>
        </div>

        {/* Play/Pause & Counter Controls */}
        <div className="flex items-center gap-2 text-xs font-mono text-zinc-400">
          <button
            onClick={() => setIsPaused((prev) => !prev)}
            className="p-1.5 rounded-lg bg-zinc-900/90 border border-zinc-800 text-zinc-300 hover:text-cyan-400 transition-colors"
            title={isPaused ? 'Resume 5-sec auto-play' : 'Pause auto-play'}
          >
            {isPaused ? <Play className="w-3.5 h-3.5 text-cyan-400" /> : <Pause className="w-3.5 h-3.5" />}
          </button>
          <span className="px-2.5 py-1 rounded-lg bg-zinc-900/90 border border-zinc-800 text-cyan-400 font-bold">
            0{currentIndex + 1} / 0{BANNER_SLIDES.length}
          </span>
        </div>
      </div>

      {/* Main Container Card */}
      <div
        id="banner-showcase-container"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        className="rounded-2xl overflow-hidden border border-zinc-800/90 hover:border-cyan-500/40 bg-zinc-950/90 shadow-2xl shadow-black/80 transition-all duration-300 flex flex-col"
      >
        {/* 1. TOP: Pure Banner Image Screen (Fully Visible) */}
        <div className="relative w-full aspect-[16/9] sm:aspect-[21/9] max-h-[460px] overflow-hidden bg-black flex items-center justify-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide.id}
              initial={{ opacity: 0, scale: 1.02 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.45, ease: 'easeOut' }}
              className="absolute inset-0 w-full h-full flex items-center justify-center"
            >
              <img
                src={currentSlide.image}
                alt={currentSlide.title}
                className="w-full h-full object-cover object-center"
                referrerPolicy="no-referrer"
              />
            </motion.div>
          </AnimatePresence>

          {/* Top Badge Overlay */}
          <div className="absolute top-3 left-3 sm:top-5 sm:left-5 z-20 flex items-center gap-2">
            <span className="px-3 py-1 rounded-md bg-gradient-to-r from-cyan-400 to-blue-600 text-black font-black text-[11px] sm:text-xs tracking-wider uppercase font-['Orbitron',sans-serif] shadow-lg shadow-cyan-500/40">
              {currentSlide.badge}
            </span>
            <span className="px-2.5 py-1 rounded-md bg-black/80 backdrop-blur-md border border-zinc-700/80 text-cyan-300 text-[10px] sm:text-[11px] font-bold">
              5s AUTO-SLIDE
            </span>
          </div>

          {/* Left Arrow Button */}
          <button
            id="banner-prev-btn"
            onClick={handlePrev}
            className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 z-20 p-2 sm:p-3 rounded-full bg-black/70 hover:bg-black/95 backdrop-blur-md border border-zinc-700/80 hover:border-cyan-400 text-white hover:text-cyan-400 transition-all shadow-xl active:scale-90"
            aria-label="Previous banner"
          >
            <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>

          {/* Right Arrow Button */}
          <button
            id="banner-next-btn"
            onClick={handleNext}
            className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 z-20 p-2 sm:p-3 rounded-full bg-black/70 hover:bg-black/95 backdrop-blur-md border border-zinc-700/80 hover:border-cyan-400 text-white hover:text-cyan-400 transition-all shadow-xl active:scale-90"
            aria-label="Next banner"
          >
            <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>
        </div>

        {/* 2. BOTTOM: Dedicated Info Section Below The Banner ("ছবি অনুযায়ী লেখা থাকবে বেনার এর নিচে") */}
        <div className="p-5 sm:p-7 bg-[#0c0d14] border-t border-zinc-800/80">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.35 }}
              className="space-y-3"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Zap className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="text-xs font-extrabold tracking-widest text-cyan-400 uppercase font-['Orbitron',sans-serif]">
                    {currentSlide.subtitle}
                  </span>
                </div>
                <span className="text-[11px] font-mono text-zinc-500 font-semibold">
                  Banner 0{currentIndex + 1} of 0{BANNER_SLIDES.length}
                </span>
              </div>

              <h3 className="text-lg sm:text-2xl md:text-3xl font-black text-white tracking-tight leading-tight uppercase font-['Orbitron',sans-serif]">
                {currentSlide.title}
              </h3>

              <p className="text-zinc-300 text-xs sm:text-sm sm:leading-relaxed">
                {currentSlide.description}
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  id={`banner-cta-${currentSlide.id}`}
                  onClick={() => onActionClick(currentSlide.resourceId)}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 via-cyan-500 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-extrabold text-xs sm:text-sm tracking-wider uppercase font-['Orbitron',sans-serif] shadow-lg shadow-cyan-500/25 active:scale-95 transition-all"
                >
                  <Eye className="w-4 h-4 stroke-[2.5]" />
                  <span>{currentSlide.ctaText}</span>
                </button>

                {currentResource && (
                  <button
                    id={`banner-direct-dl-${currentSlide.id}`}
                    onClick={() => onDownloadClick(currentResource)}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-purple-600/90 hover:bg-purple-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-purple-600/25 active:scale-95 transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download File</span>
                  </button>
                )}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* 3. Bottom Navigation Indicators & Thumbnail Bar */}
        <div className="px-5 py-3 sm:px-7 sm:py-4 bg-[#08090e] border-t border-zinc-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {BANNER_SLIDES.map((slide, idx) => {
              const isActive = idx === currentIndex;
              return (
                <button
                  key={slide.id}
                  id={`banner-dot-${idx}`}
                  onClick={() => setCurrentIndex(idx)}
                  className={`h-2.5 rounded-full transition-all duration-300 flex items-center justify-center ${
                    isActive
                      ? 'w-10 bg-gradient-to-r from-cyan-400 to-purple-500 shadow-md shadow-cyan-400/50'
                      : 'w-3 bg-zinc-700 hover:bg-zinc-500'
                  }`}
                  aria-label={`Jump to Banner ${idx + 1}`}
                />
              );
            })}
          </div>

          <div className="text-[11px] text-zinc-400 flex items-center gap-1.5 font-medium">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Changes automatically every 5 seconds</span>
            <span className="sm:hidden">5s Auto-play</span>
          </div>
        </div>
      </div>
    </section>
  );
};
