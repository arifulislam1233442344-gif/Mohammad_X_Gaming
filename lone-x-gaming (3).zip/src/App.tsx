import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { BannerSlider } from './components/BannerSlider';
import { SearchFilter } from './components/SearchFilter';
import { ResourceCard } from './components/ResourceCard';
import { SocialSection } from './components/SocialSection';
import { Footer } from './components/Footer';
import { DownloadModal } from './components/DownloadModal';
import { GuideViewerModal } from './components/GuideViewerModal';
import { PolicyModal, PolicyModalType } from './components/PolicyModal';
import { Toast } from './components/Toast';

import { RESOURCES_DATA } from './data/resources';
import { FEATURED_PROMO } from './data/config';
import { ResourceCategory, ResourceItem } from './types';
import { Sparkles, Download, Layers, HelpCircle } from 'lucide-react';

export default function App() {
  // State for search and filtering
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<ResourceCategory>('all');
  const [sortBy, setSortBy] = useState<'latest' | 'popular' | 'size'>('latest');

  // Modals state
  const [activeDownloadResource, setActiveDownloadResource] = useState<ResourceItem | null>(null);
  const [activeGuideResource, setActiveGuideResource] = useState<ResourceItem | null>(null);
  const [policyModalType, setPolicyModalType] = useState<PolicyModalType>(null);

  // Toast feedback state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  // Find the featured resource item
  const featuredResource = useMemo(() => {
    return (
      RESOURCES_DATA.find((r) => r.id === FEATURED_PROMO.resourceId) ||
      RESOURCES_DATA[0]
    );
  }, []);

  // Filtered and sorted resources list
  const filteredResources = useMemo(() => {
    return RESOURCES_DATA.filter((item) => {
      // Category filter
      if (selectedCategory !== 'all' && item.category !== selectedCategory) {
        return false;
      }
      // Search query filter
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(query);
        const matchesDesc = item.shortDescription.toLowerCase().includes(query);
        const matchesVersion = item.version.toLowerCase().includes(query);
        const matchesCategory = item.category.toLowerCase().includes(query);
        return matchesName || matchesDesc || matchesVersion || matchesCategory;
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'popular') {
        return b.downloadsCount - a.downloadsCount;
      }
      if (sortBy === 'size') {
        const sizeA = parseFloat(a.fileSize);
        const sizeB = parseFloat(b.fileSize);
        return sizeB - sizeA;
      }
      // default 'latest'
      return b.updatedDate.localeCompare(a.updatedDate);
    });
  }, [searchQuery, selectedCategory, sortBy]);

  // Smooth scroll helper
  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleCopySiteLink = () => {
    navigator.clipboard.writeText(window.location.href);
    showNotification('Portal link copied to clipboard!');
  };

  const handleCopyHandle = (handle: string) => {
    navigator.clipboard.writeText(handle);
    showNotification(`Copied ${handle} to clipboard!`);
  };

  const handleOpenFeaturedGuide = (resourceId: string) => {
    const target = RESOURCES_DATA.find((r) => r.id === resourceId) || featuredResource;
    setActiveGuideResource(target);
  };

  return (
    <div className="min-h-screen bg-[#08090e] text-zinc-100 cyber-grid flex flex-col selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Sticky Header */}
      <Header onScrollToSection={scrollToSection} />

      <main className="flex-1">
        {/* 1. Hero / Profile Section */}
        <HeroSection
          onScrollToDownloads={() => scrollToSection('resources-section')}
          onCopySiteLink={handleCopySiteLink}
        />

        {/* 2. Free Fire Gaming Banner Slider System */}
        <BannerSlider
          onActionClick={handleOpenFeaturedGuide}
          onDownloadClick={(resource) => setActiveDownloadResource(resource)}
          findResourceById={(id) => RESOURCES_DATA.find((r) => r.id === id)}
        />

        {/* 3 & 4. Downloads & Resources Section with Search and Filters */}
        <section
          id="resources-section"
          className="py-10 sm:py-16 px-4 sm:px-6 max-w-5xl mx-auto w-full"
        >
          {/* Section Heading */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 sm:mb-8">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-bold uppercase tracking-wider mb-2">
                <Download className="w-3.5 h-3.5" />
                <span>Verified Direct Downloads</span>
              </div>
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-black uppercase text-white tracking-wide font-['Orbitron',sans-serif]">
                Gaming Resources & Files
              </h2>
              <p className="text-sm text-zinc-400 mt-1 max-w-xl">
                Browse our library of pro sensitivity matrices, custom claw HUD setups, 120 FPS configs, and tournament rulebooks.
              </p>
            </div>

            {/* Quick stats pill */}
            <div className="flex items-center gap-3 text-xs text-zinc-400 bg-zinc-900/80 px-4 py-2 rounded-xl border border-zinc-800 self-start md:self-auto">
              <span className="flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-purple-400" />
                <strong className="text-white">{RESOURCES_DATA.length}</strong> Safe Files
              </span>
              <span className="text-zinc-600">•</span>
              <span className="text-emerald-400 font-semibold">100% Free</span>
            </div>
          </div>

          {/* 4. Search and Filter Bar */}
          <div className="mb-8">
            <SearchFilter
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              selectedCategory={selectedCategory}
              onCategoryChange={setSelectedCategory}
              sortBy={sortBy}
              onSortChange={setSortBy}
              totalCount={filteredResources.length}
            />
          </div>

          {/* 3. Resource Cards List */}
          {filteredResources.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
              {filteredResources.map((resource) => (
                <ResourceCard
                  key={resource.id}
                  resource={resource}
                  onDownload={(res) => setActiveDownloadResource(res)}
                  onPreview={(res) => setActiveGuideResource(res)}
                />
              ))}
            </div>
          ) : (
            <div className="p-10 rounded-2xl bg-zinc-900/50 border border-zinc-800 text-center space-y-3">
              <HelpCircle className="w-8 h-8 text-zinc-500 mx-auto" />
              <h3 className="text-lg font-bold text-white">No resources found</h3>
              <p className="text-sm text-zinc-400 max-w-md mx-auto">
                No guides or files matched &quot;{searchQuery}&quot;. Try checking for different keywords like &quot;sensitivity&quot;, &quot;HUD&quot;, or &quot;graphics&quot;.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('all');
                }}
                className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-cyan-400 text-xs font-bold transition-colors"
              >
                Reset Search Filters
              </button>
            </div>
          )}
        </section>

        {/* 5. Social Media Section */}
        <SocialSection onCopyHandle={handleCopyHandle} />
      </main>

      {/* 6. Footer */}
      <Footer onOpenPolicy={(type) => setPolicyModalType(type)} />

      {/* Interactive Download Modal */}
      <DownloadModal
        resource={activeDownloadResource}
        isOpen={Boolean(activeDownloadResource)}
        onClose={() => setActiveDownloadResource(null)}
        onOpenGuideViewer={(res) => setActiveGuideResource(res)}
        onNotify={showNotification}
      />

      {/* Interactive Guide Details Viewer Modal */}
      <GuideViewerModal
        resource={activeGuideResource}
        isOpen={Boolean(activeGuideResource)}
        onClose={() => setActiveGuideResource(null)}
        onTriggerDownload={(res) => setActiveDownloadResource(res)}
        onNotify={showNotification}
      />

      {/* Privacy Policy, Disclaimer, Contact Modals */}
      <PolicyModal
        type={policyModalType}
        isOpen={Boolean(policyModalType)}
        onClose={() => setPolicyModalType(null)}
        onNotify={showNotification}
      />

      {/* Toast Notification */}
      <Toast message={toastMessage} onDismiss={() => setToastMessage(null)} />
    </div>
  );
}
